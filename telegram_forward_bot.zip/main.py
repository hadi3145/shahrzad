
import os
import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
import aiohttp

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHANNELS = os.getenv("SOURCE_CHANNELS").split(",")
TARGET_CHANNEL = os.getenv("TARGET_CHANNEL")
AI_ENDPOINT = os.getenv("AI_API_URL")
AI_KEY = os.getenv("AI_API_KEY")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

async def rephrase_text(text):
    async with aiohttp.ClientSession() as session:
        async with session.post(
            AI_ENDPOINT,
            headers={"Authorization": f"Bearer {AI_KEY}"},
            json={"inputs": text},
        ) as response:
            if response.status == 200:
                result = await response.json()
                return result[0]["generated_text"]
            return text

@dp.message_handler(content_types=types.ContentType.TEXT)
async def handle_message(message: types.Message):
    if message.chat.username in [ch.replace("https://t.me/", "") for ch in CHANNELS]:
        cleaned = message.text.split("\n")
        cleaned = [line for line in cleaned if not line.startswith("@") and "t.me/" not in line]
        cleaned_text = "\n".join(cleaned)
        new_text = await rephrase_text(cleaned_text)
        new_text += f"\n\n@{TARGET_CHANNEL}"
        await bot.send_message(chat_id=f"@{TARGET_CHANNEL}", text=new_text)

if __name__ == "__main__":
    executor.start_polling(dp)
